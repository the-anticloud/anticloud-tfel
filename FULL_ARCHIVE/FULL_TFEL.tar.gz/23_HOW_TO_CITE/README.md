# 23 How To Cite

**Project:** TFEL
**Upstream:** https://github.com/thelfer/tfel

Content specific to TFEL in category CHEMICAL_PRODUCTION.
