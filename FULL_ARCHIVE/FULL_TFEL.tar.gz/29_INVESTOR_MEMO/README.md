# 29 Investor Memo

**Project:** TFEL
**Upstream:** https://github.com/thelfer/tfel

Content specific to TFEL in category CHEMICAL_PRODUCTION.
