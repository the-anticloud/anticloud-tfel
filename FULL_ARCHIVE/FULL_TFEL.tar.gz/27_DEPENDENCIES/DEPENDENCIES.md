# Dependencies — TFEL

**Upstream:** https://github.com/thelfer/tfel (GPL)

## Anticloud Core Dependencies

| Package | Version | License | Purpose |
| --- | --- | --- | --- |
| llama-cpp-python | >=0.2.0 | MIT | PAX local inference |
| cryptography | >=41.0 | Apache 2.0 | AES-256 encryption |
| huggingface_hub | >=0.20 | Apache 2.0 | Model download |
| numpy | >=1.24 | BSD | Numerical computation |
| requests | >=2.31 | Apache 2.0 | HTTP client |

## Upstream Dependencies

See upstream repository for full dependency list.
All upstream dependencies verified MIT or Apache 2.0.

## Pinned Versions

requirements-anticloud.txt generated at build time with exact version pins.
No floating dependencies in production builds.
